export const environment = {
  production: true,
  urlAPI: 'https://triplo-api.herokuapp.com'
};
