import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-example-code',
  templateUrl: './example-code.component.html',
  styleUrls: ['./example-code.component.css']
})
export class ExampleCodeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}
